<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title>Моя музыка</title>

    <!-- Favicon -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Core Stylesheet -->
    <link rel="stylesheet" href="style.css">

</head>

<body>
    <!-- ##### Header Area Start ##### -->
    <header class="header-area">
        <!-- Navbar Area -->
        <div class="nikki-main-menu">
            <div class="classy-nav-container breakpoint-off">
                <div class="container-fluid">
                    <!-- Menu -->
                    <nav class="classy-navbar justify-content-between" id="nikkiNav">

                        <!-- Nav brand -->
                        <a href="index.php" class="nav-brand" style="text-transform: uppercase">Моя музыка</a>

                        <!-- Navbar Toggler -->
                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <!-- Menu -->
                        <div class="classy-menu">

                            <!-- close btn -->
                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>

                            <!-- Nav Start -->
                            <div class="classynav">
                                <ul>
                                    <li><a href="index.php">Главная</a></li>
                                    <li><a href="#">Статьи</a>
                                        <ul class="dropdown">
                                            
                                            <li><a href="8b502500f35625f857e348a98e1a6ab3.php">Тема: «Изори...</a></li>
                                            

                                            <li><a href="bf9c3f92fc79eeeb26a46e3b031d507e.php">Тема: «Почем...</a></li>
                                            

                                            <li><a href="905bff03b65eb8dba60c39f967a14685.php">Тема: «Компо...</a></li>
                                            

                                            <li><a href="447b28cf053dcca266e8f91dbacf6eec.php">Тема: «Почем...</a></li>
                                            

                                            <li><a href="e08edde7154a398825774a2d3ce15884.php">Тема: «Музык...</a></li>
                                            

                                        </ul>
                                    </li>
                                    <li><a href="contact.php">Контакты</a></li>
                                    <li><a href="terms.php">Условия и положения</a></li>
                                    <li><a href="policy.php">Политика конфиденциальности</a></li>
                                </ul>
                            </div>
                            <!-- Nav End -->
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>

    <!-- ##### Blog Content Area Start ##### -->
    <section class="blog-content-area section-padding-100">
        <div class="container">

            <div class="row justify-content-center">
                <!-- Blog Posts Area -->
                <div class="col-12 col-lg-8">
                    <div class="blog-posts-area">
                        <div class="row">

                            <!-- Featured Post Area -->
                            <div class="col-12">
                                <div class="featured-post-area mb-50">
                                    <!-- Thumbnail -->
                                    <div class="post-thumbnail mb-30">
                                        <a href="#"><img src="./img/1000633-music-nevseoboi.com.ua.jpg" alt=""></a>
                                    </div>
                                    <!-- Featured Post Content -->
                                    <div class="featured-post-content">
                                        <p class="post-date">MAY 10, 2020 </p>
                                        <a href="#" class="post-title">
                                            <h2>Музыку мы любим!</h2>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Single Blog Post -->
                            <div class="col-12 col-sm-6">
                                <div class="single-blog-post mb-50">
                                    <!-- Thumbnail -->
                                    <div class="post-thumbnail">
                                        <a href="8b502500f35625f857e348a98e1a6ab3.php"><img src="./img/0054193_www.nevseoboi.com.ua.jpg" alt=""></a>
                                    </div>
                                    <!-- Content -->
                                    <div class="post-content">
                                        <p class="post-date">MAY 1, 2020 </p>
                                        <a href="8b502500f35625f857e348a98e1a6ab3.php" class="post-title">
                                            <h4>Тема: «Изоритмический рефрен в XXI веке»</h4>
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <!-- Single Blog Post -->
                            

                            <!-- Single Blog Post -->
                            <div class="col-12 col-sm-6">
                                <div class="single-blog-post mb-50">
                                    <!-- Thumbnail -->
                                    <div class="post-thumbnail">
                                        <a href="bf9c3f92fc79eeeb26a46e3b031d507e.php"><img src="./img/0054187_www.nevseoboi.com.ua.jpg" alt=""></a>
                                    </div>
                                    <!-- Content -->
                                    <div class="post-content">
                                        <p class="post-date">MAY 19, 2020 </p>
                                        <a href="bf9c3f92fc79eeeb26a46e3b031d507e.php" class="post-title">
                                            <h4>Тема: «Почему вероятна серпантинная волна?»</h4>
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <!-- Single Blog Post -->
                            

                            <!-- Single Blog Post -->
                            <div class="col-12 col-sm-6">
                                <div class="single-blog-post mb-50">
                                    <!-- Thumbnail -->
                                    <div class="post-thumbnail">
                                        <a href="905bff03b65eb8dba60c39f967a14685.php"><img src="./img/0054105_www.nevseoboi.com.ua.jpg" alt=""></a>
                                    </div>
                                    <!-- Content -->
                                    <div class="post-content">
                                        <p class="post-date">MAY 21, 2020 </p>
                                        <a href="905bff03b65eb8dba60c39f967a14685.php" class="post-title">
                                            <h4>Тема: «Композиционный midi-контроллер: основные моменты»</h4>
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <!-- Single Blog Post -->
                            

                            <!-- Single Blog Post -->
                            <div class="col-12 col-sm-6">
                                <div class="single-blog-post mb-50">
                                    <!-- Thumbnail -->
                                    <div class="post-thumbnail">
                                        <a href="447b28cf053dcca266e8f91dbacf6eec.php"><img src="./img/0054123_www.nevseoboi.com.ua.jpg" alt=""></a>
                                    </div>
                                    <!-- Content -->
                                    <div class="post-content">
                                        <p class="post-date">MAY 18, 2020 </p>
                                        <a href="447b28cf053dcca266e8f91dbacf6eec.php" class="post-title">
                                            <h4>Тема: «Почему возможна форма?»</h4>
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <!-- Single Blog Post -->
                            

                            <!-- Single Blog Post -->
                            <div class="col-12 col-sm-6">
                                <div class="single-blog-post mb-50">
                                    <!-- Thumbnail -->
                                    <div class="post-thumbnail">
                                        <a href="e08edde7154a398825774a2d3ce15884.php"><img src="./img/0054211_www.nevseoboi.com.ua.jpg" alt=""></a>
                                    </div>
                                    <!-- Content -->
                                    <div class="post-content">
                                        <p class="post-date">MAY 9, 2020 </p>
                                        <a href="e08edde7154a398825774a2d3ce15884.php" class="post-title">
                                            <h4>Тема: «Музыкальный динамический эллипсис: гипотеза и теории»</h4>
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <!-- Single Blog Post -->
                            

                        </div>
                    </div>
                </div>

                <!-- Blog Sidebar Area -->
                <div class="col-12 col-sm-9 col-md-6 col-lg-4">
                    <div class="post-sidebar-area">

                        <!-- ##### Single Widget Area ##### -->
                        <div class="single-widget-area mb-30">
                            <!-- Title -->
                            <div class="widget-title">
                                <h6>Социальные медиа</h6>
                            </div>
                            <!-- Widget Social Info -->
                            <div class="widget-social-info text-center">
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-instagram"></i></a>
                                <a href="#"><i class="fa fa-google-plus"></i></a>
                                <a href="#"><i class="fa fa-pinterest"></i></a>
                                <a href="#"><i class="fa fa-linkedin"></i></a>
                                <a href="#"><i class="fa fa-rss"></i></a>
                            </div>
                        </div>

                        <!-- ##### Single Widget Area ##### -->
                        <div class="single-widget-area mb-30">
                            <!-- Title -->
                            <div class="widget-title">
                                <h6>Недавние посты</h6>
                            </div>

                            
                            <!-- Single Latest Posts -->
                            <div class="single-latest-post d-flex">
                                <div class="post-thumb">
                                    <img src="./img/0054193_www.nevseoboi.com.ua.jpg" alt="">
                                </div>
                                <div class="post-content">
                                    <a href="8b502500f35625f857e348a98e1a6ab3.php" class="post-title">
                                        <h6>Тема: «Изоритмический рефрен в XXI веке»</h6>
                                    </a>
                                    <a href="8b502500f35625f857e348a98e1a6ab3.php" class="post-author"><span></span> Леонид</a>
                                </div>
                            </div>
                            

                            <!-- Single Latest Posts -->
                            <div class="single-latest-post d-flex">
                                <div class="post-thumb">
                                    <img src="./img/0054187_www.nevseoboi.com.ua.jpg" alt="">
                                </div>
                                <div class="post-content">
                                    <a href="bf9c3f92fc79eeeb26a46e3b031d507e.php" class="post-title">
                                        <h6>Тема: «Почему вероятна серпантинная волна?»</h6>
                                    </a>
                                    <a href="bf9c3f92fc79eeeb26a46e3b031d507e.php" class="post-author"><span></span> Леонид</a>
                                </div>
                            </div>
                            

                            <!-- Single Latest Posts -->
                            <div class="single-latest-post d-flex">
                                <div class="post-thumb">
                                    <img src="./img/0054105_www.nevseoboi.com.ua.jpg" alt="">
                                </div>
                                <div class="post-content">
                                    <a href="905bff03b65eb8dba60c39f967a14685.php" class="post-title">
                                        <h6>Тема: «Композиционный midi-контроллер: основные моменты»</h6>
                                    </a>
                                    <a href="905bff03b65eb8dba60c39f967a14685.php" class="post-author"><span></span> Леонид</a>
                                </div>
                            </div>
                            

                            <!-- Single Latest Posts -->
                            <div class="single-latest-post d-flex">
                                <div class="post-thumb">
                                    <img src="./img/0054123_www.nevseoboi.com.ua.jpg" alt="">
                                </div>
                                <div class="post-content">
                                    <a href="447b28cf053dcca266e8f91dbacf6eec.php" class="post-title">
                                        <h6>Тема: «Почему возможна форма?»</h6>
                                    </a>
                                    <a href="447b28cf053dcca266e8f91dbacf6eec.php" class="post-author"><span></span> Леонид</a>
                                </div>
                            </div>
                            



                        </div>


                        <!-- ##### Single Widget Area ##### -->
                        <div class="single-widget-area mb-30">
                            <!-- Title -->
                            <div class="widget-title">
                                <h6>Рассылка</h6>
                            </div>
                            <!-- Content -->
                            <div class="newsletter-content">
                                <p>Введите ваш email чтобы получать новые статьи нашего блога</p>
                                <form action="thanks.php" method="post">
                                    <input type="email" name="email" class="form-control" placeholder="Email">
                                    <button><i class="fa fa-send"></i></button>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ##### Blog Content Area End ##### -->

    <!-- ##### Instagram Area Start ##### -->
    <div class="follow-us-instagram">
        <div class="instagram-content d-flex flex-wrap align-items-center">

            <!-- Single Instagram Slide -->
            <div class="single-instagram">
                <img src="./img/1000430-music-nevseoboi.com.ua.jpg" alt="">
                <a href="#"><i class="fa fa-instagram"></i></a>
            </div>

            <!-- Single Instagram Slide -->
            <div class="single-instagram">
                <img src="./img/0054170_www.nevseoboi.com.ua.jpg" alt="">
                <a href="#"><i class="fa fa-instagram"></i></a>
            </div>

            <!-- Single Instagram Slide -->
            <div class="single-instagram">
                <img src="./img/0054086_www.nevseoboi.com.ua.jpg" alt="">
                <a href="#"><i class="fa fa-instagram"></i></a>
            </div>

            <!-- Single Instagram Slide -->
            <div class="single-instagram">
                <img src="./img/1000636-music-nevseoboi.com.ua.jpg" alt="">
                <a href="#"><i class="fa fa-instagram"></i></a>
            </div>

            <!-- Single Instagram Slide -->
            <div class="single-instagram">
                <img src="./img/1000441-music-nevseoboi.com.ua.jpg" alt="">
                <a href="#"><i class="fa fa-instagram"></i></a>
            </div>

            <!-- Single Instagram Slide -->
            <div class="single-instagram">
                <img src="./img/0054140_www.nevseoboi.com.ua.jpg" alt="">
                <a href="#"><i class="fa fa-instagram"></i></a>
            </div>

            <!-- Single Instagram Slide -->
            <div class="single-instagram">
                <img src="./img/1000640-music-nevseoboi.com.ua.jpg" alt="">
                <a href="#"><i class="fa fa-instagram"></i></a>
            </div>

            <!-- Single Instagram Slide -->
            <div class="single-instagram">
                <img src="./img/1000628-music-nevseoboi.com.ua.jpg" alt="">
                <a href="#"><i class="fa fa-instagram"></i></a>
            </div>
        </div>
    </div>
    <!-- ##### Instagram Area End ##### -->

    <!-- ##### Footer Area Start ##### -->
    <footer class="footer-area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <!-- Footer Social Info -->
                    <div class="footer-social-info d-flex align-items-center justify-content-between">
                        <a href="#"><i class="fa fa-facebook"></i><span>Facebook</span></a>
                        <a href="#"><i class="fa fa-twitter"></i><span>Twitter</span></a>
                        <a href="#"><i class="fa fa-google-plus"></i><span>Google +</span></a>
                        <a href="#"><i class="fa fa-linkedin"></i><span>linkedin</span></a>
                        <a href="#"><i class="fa fa-instagram"></i><span>Instagram</span></a>
                        <a href="#"><i class="fa fa-vimeo"></i><span>Vimeo</span></a>
                        <a href="#"><i class="fa fa-youtube"></i><span>Youtube</span></a>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="copywrite-text">
                        <p>
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved </p>
                        <p>
                            <a 
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- ##### Footer Area Start ##### -->

    <!-- ##### All Javascript Script ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
    <div class='cookie-banner'>
        <p>
            Сайт использует файлы cookie. Они позволяют узнавать вас и получать информацию о вашем пользовательском опыте.Продолжая просмотр сайта, я соглашаюсь с использованием файлов cookie владельцем сайта в соответствии с <a target="_blank" href="https://en.wikipedia.org/wiki/HTTP_cookie">Политикой cookie</a>
        </p>
        <button class='close-cookie'>&times;</button>
    </div>
    <script>
        window.onload = function() {
            $('.close-cookie').click(function () {
                $('.cookie-banner').fadeOut();
            })
        }
    </script>
    <script>
        let elems = document.querySelectorAll('.server-name');
        elems.forEach((elem) => {
            elem.innerHTML = window.location.hostname
        })
    </script>
</body>

</html>